import ServerOverviewClient from "@/app/[locale]/(main)/ClientComponents/ServerOverviewClient";

export default async function ServerOverview() {
  return <ServerOverviewClient />;
}
