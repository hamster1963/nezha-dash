import ServerListClient from "@/app/[locale]/(main)/ClientComponents/ServerListClient";
import React from "react";

export default async function ServerList() {
  return <ServerListClient />;
}
